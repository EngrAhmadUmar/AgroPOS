package co.mikie.micha.agro_pos;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
